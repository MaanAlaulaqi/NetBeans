The idea was simple, driver's point of view, 
driving down a highway, trees appearing in the distant(small) 
and growing as they get closer. Same concept with the street lines. 

The idea for the sky was that all the RGB values will
hit 0,0,0 at the same time, and then go back up to the "daylight"
values, depending on a percentage, as to have a smooth flow. 

A sun, a moon, stars and clouds, a random UFO passing by every 1 minute
They were part of the concept. 

I wasn't able to deliver the final project, but I wanted to let you 
know what the idea behind a gray and green block was.